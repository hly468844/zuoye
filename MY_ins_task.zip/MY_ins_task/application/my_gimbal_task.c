#include "CAN_receive.h"
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#define PITODU 114.59156098; 

extern fp32 INS_angle[3];
extern fp32 jiaodu[3];

fp32 yaw,pitch;

typedef enum
{
	STATE_IDLE=0,
	STATE_ENABLE,
	STATE_FOLLOW,
	STATE_AIMING
}state;
typedef enum
{
	EVENT_DISABLE=0,
  EVENT_ENABLE,
	EVENT_FOLLOW,
	EVENT_AIMING
}Event;


void state_ran(Event ev);
void follow_run(void);
void aiming_run(void);




uint8_t current_state=STATE_IDLE;
uint8_t ev;

int16_t i1,i2;








void my_gimbal_task(void const * argument)
{
  while(1)
	{
	CAN_cmd_chassis(i1,0,0,0);
		vTaskDelay(2);
	CAN_cmd_gimbal(i2,0,0,0);
		vTaskDelay(2);
	//	state_ran(ev);
		
	}
}














void follow_run(void)
{
		

}


void aiming_run(void)
{
		

}




void state_ran(Event ev)
{
	switch(current_state){
		case STATE_IDLE:
			if(ev==EVENT_ENABLE)
			{
				current_state=STATE_ENABLE;
			}
		break;
		
		case STATE_ENABLE:
			if(ev==EVENT_FOLLOW)
			{
				current_state=STATE_FOLLOW;
				follow_run();
			}
			else if(ev==EVENT_AIMING)
			{
				current_state=STATE_AIMING;
				aiming_run();
			}
		break;
		
		case STATE_FOLLOW:
			if(ev==EVENT_FOLLOW)
			{
				follow_run();
			}
			else if(ev==EVENT_AIMING)
			{
				current_state=STATE_AIMING;
				aiming_run();
			}
			else if(ev==EVENT_DISABLE)
			{
				current_state=STATE_IDLE;
			}
		break;
		
		case STATE_AIMING:
			if(ev==EVENT_FOLLOW)
			{
				current_state=STATE_FOLLOW;
				follow_run();
			}
			else if(ev==EVENT_AIMING)
			{
				aiming_run();
			}
			else if(ev==EVENT_DISABLE)
			{
				current_state=STATE_IDLE;
			}
		break;
	}
}