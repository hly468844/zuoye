my_ins_task/tasks.o: ..\Middlewares\Third_Party\FreeRTOS\Source\tasks.c \
  D:\stm32app\keil5\core\ARM\ARMCLANG\Bin\..\include\stdlib.h \
  D:\stm32app\keil5\core\ARM\ARMCLANG\Bin\..\include\string.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\FreeRTOS.h \
  D:\stm32app\keil5\core\ARM\ARMCLANG\Bin\..\include\stddef.h \
  D:\stm32app\keil5\core\ARM\ARMCLANG\Bin\..\include\stdint.h \
  ..\Core\Inc\FreeRTOSConfig.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\projdefs.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\portable.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\deprecated_definitions.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\portable\RVDS\ARM_CM4F\portmacro.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\mpu_wrappers.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\task.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\list.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\timers.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\stack_macros.h
